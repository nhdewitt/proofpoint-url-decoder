// rest_client_test.go
package main_test

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"net/url"
	"strings"
	"testing"
)

const baseURL = "http://localhost:8089"

func TestRootHandler(t *testing.T) {
	resp, err := http.Get(baseURL + "/")
	if err != nil {
		t.Fatalf("GET / failed: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		t.Errorf("Expected status 200, got %d", resp.StatusCode)
	}

	body, _ := ioutil.ReadAll(resp.Body)
	if !strings.Contains(string(body), "<title>Proofpoint URL Decoder") {
		t.Errorf("Unexpected body for GET /:\n%s", body)
	}
}

func TestAPIDecodeSuccess(t *testing.T) {
	payload := map[string][]string{
		"urls": {
			"https://urldefense.proofpoint.com/v1/url?u=http://example.com/&k=TESTKEY",
		},
	}
	b, _ := json.Marshal(payload)

	resp, err := http.Post(baseURL+"/api/decode", "application/json", bytes.NewReader(b))
	if err != nil {
		t.Fatalf("POST /api/decode failed: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		t.Errorf("Expected status 200, got %d", resp.StatusCode)
	}

	var result struct {
		Results []string `json:"results"`
		Errors  []string `json:"errors"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		t.Fatalf("Decoding JSON response failed: %v", err)
	}

	if len(result.Results) != 1 {
		t.Fatalf("Expected 1 result, got %d", len(result.Results))
	}
	if !strings.HasPrefix(result.Results[0], "http://example.com/") {
		t.Errorf("Decoded URL mismatch, got %q", result.Results[0])
	}
	if len(result.Errors) > 0 && result.Errors[0] != "" {
		t.Errorf("Unexpected error in response: %v", result.Errors)
	}
}

func TestAPIDecodeInvalidJSON(t *testing.T) {
	resp, err := http.Post(baseURL+"/api/decode", "application/json", strings.NewReader("{invalid"))
	if err != nil {
		t.Fatalf("POST /api/decode with bad JSON failed: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusBadRequest {
		t.Errorf("Expected 400 Bad Request, got %d", resp.StatusCode)
	}
}

func TestAPIDecodeWrongMethod(t *testing.T) {
	req, _ := http.NewRequest("GET", baseURL+"/api/decode", nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("GET /api/decode failed: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusMethodNotAllowed {
		t.Errorf("Expected 405 Method Not Allowed, got %d", resp.StatusCode)
	}
}

func TestHTMLDecodeFallback(t *testing.T) {
	form := url.Values{}
	form.Set("input", "https://urldefense.proofpoint.com/v1/url?u=http://golang.org/&k=KEY")

	resp, err := http.PostForm(baseURL+"/decode", form)
	if err != nil {
		t.Fatalf("POST /decode failed: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		t.Errorf("Expected 200 OK, got %d", resp.StatusCode)
	}

	body, _ := ioutil.ReadAll(resp.Body)
	if !strings.Contains(string(body), "http://golang.org/") {
		t.Errorf("Decoded HTML page missing expected URL, body:\n%s", body)
	}
}
